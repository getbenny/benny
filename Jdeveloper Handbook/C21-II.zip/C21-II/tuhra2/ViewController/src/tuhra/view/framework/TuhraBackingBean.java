package tuhra.view.framework;

import oracle.adf.model.BindingContext;

import oracle.binding.BindingContainer;

public abstract class TuhraBackingBean {


    /**
     * Provide standardized access to the binding context for all backing 
     * beans
     * @return bindings
     */
    public BindingContainer getBindings() {
        return BindingContext.getCurrent().getCurrentBindingsEntry();
    }
}
