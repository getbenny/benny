@@hr_drop
@@hr_main
purge recyclebin
/
exit

