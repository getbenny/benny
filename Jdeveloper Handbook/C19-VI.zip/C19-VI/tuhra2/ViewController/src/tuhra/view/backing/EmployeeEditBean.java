package tuhra.view.backing;

import oracle.binding.AttributeBinding;
import oracle.binding.OperationBinding;

import tuhra.view.framework.TuhraBackingBean;


public class EmployeeEditBean extends TuhraBackingBean {


    public String lockIcon_action() {
        // Access the Locked attribute binding
        AttributeBinding lockedBinding =
            (AttributeBinding)getBindings().getControlBinding("Locked");
        Boolean locked = false;
        if (lockedBinding != null) {
            //Get the current value of the transient attr
            locked = (Boolean)lockedBinding.getInputValue();
        }
        //The attribute may be null if no detail record exists yet
        if (locked == null) {
            // Set a default value
            locked = true;
            // Create a Biographies record
            OperationBinding createBio =
                getBindings().getOperationBinding("CreateBio");
            if (createBio != null) {
                createBio.execute();
            }
        }
        //Toggle the locked state
        lockedBinding.setInputValue(!locked);
        return null;
    }
}
