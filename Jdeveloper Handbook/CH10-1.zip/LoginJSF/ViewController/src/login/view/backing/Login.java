package login.view.backing;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

import oracle.adf.view.rich.component.rich.RichDocument;
import oracle.adf.view.rich.component.rich.RichForm;
import oracle.adf.view.rich.component.rich.input.RichInputText;
import oracle.adf.view.rich.component.rich.layout.RichPanelFormLayout;
import oracle.adf.view.rich.component.rich.layout.RichPanelHeader;
import oracle.adf.view.rich.component.rich.nav.RichCommandButton;
import oracle.adf.view.rich.component.rich.output.RichOutputText;

public class Login
{
  private RichForm loginForm;
  private RichDocument d2;
  private RichPanelHeader ph1;
  private RichPanelFormLayout pfl1;
  private RichInputText usernameField;
  private RichInputText passwordField;
  private RichCommandButton loginButton;
  private RichOutputText ot1;
  int loginAttempts = 0;

  public void setLoginForm(RichForm form)
  {
    this.loginForm = form;
  }

  public RichForm getLoginForm()
  {
    return loginForm;
  }

  public void setD2(RichDocument d2)
  {
    this.d2 = d2;
  }

  public RichDocument getD2()
  {
    return d2;
  }

  public void setPh1(RichPanelHeader ph1)
  {
    this.ph1 = ph1;
  }

  public RichPanelHeader getPh1()
  {
    return ph1;
  }

  public void setPfl1(RichPanelFormLayout pfl1)
  {
    this.pfl1 = pfl1;
  }

  public RichPanelFormLayout getPfl1()
  {
    return pfl1;
  }

  public void setUsernameField(RichInputText it1)
  {
    this.usernameField = it1;
  }

  public RichInputText getUsernameField()
  {
    return usernameField;
  }

  public void setPasswordField(RichInputText it2)
  {
    this.passwordField = it2;
  }

  public RichInputText getPasswordField()
  {
    return passwordField;
  }

  public void setLoginButton(RichCommandButton cb1)
  {
    this.loginButton = cb1;
  }

  public RichCommandButton getLoginButton()
  {
    return loginButton;
  }

  public void setOt1(RichOutputText ot1)
  {
    this.ot1 = ot1;
  }

  public RichOutputText getOt1()
  {
    return ot1;
  }

  public String loginButton_action()
  {
    FacesContext messageContext = FacesContext.getCurrentInstance();
    String returnResult = "gohome";
    loginAttempts++;
    if (!passwordField.getValue().toString().equals("JSF"))
    {
      returnResult = null;
      if (loginAttempts >= 3)
      {
        // message displayed in the FacesContext dialog
        messageContext.addMessage(null,
                                  new FacesMessage("You seem " + " to have forgotten that the password is \"JSF.\""));
      }
      else
      {
        messageContext.addMessage(null,
                                  new FacesMessage("Incorrect login. Try again."));
      }
    }
    else
    {
      loginAttempts = 0;
      passwordField.setValue(null);
    }
    return returnResult;

  }
}
