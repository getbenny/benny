package tuhra.model.framework;

import oracle.jbo.server.ApplicationModuleImpl;

public class TuhraApplicationModuleImpl extends ApplicationModuleImpl {
}
