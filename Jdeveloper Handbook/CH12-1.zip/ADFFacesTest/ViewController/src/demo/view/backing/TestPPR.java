package demo.view.backing;

import oracle.adf.view.rich.component.rich.RichDocument;
import oracle.adf.view.rich.component.rich.RichForm;
import oracle.adf.view.rich.component.rich.input.RichInputText;
import oracle.adf.view.rich.component.rich.layout.RichPanelFormLayout;
import oracle.adf.view.rich.component.rich.layout.RichPanelLabelAndMessage;
import oracle.adf.view.rich.component.rich.nav.RichCommandButton;
import oracle.adf.view.rich.component.rich.output.RichOutputText;

public class TestPPR
{
  private RichForm f2;
  private RichDocument d2;
  private RichPanelFormLayout pfl1;
  private RichInputText it1;
  private RichOutputText ot1;
  private RichInputText it2;
  private RichPanelLabelAndMessage plam1;
  private RichCommandButton cb1;

  public void setF2(RichForm f2)
  {
    this.f2 = f2;
  }

  public RichForm getF2()
  {
    return f2;
  }

  public void setD2(RichDocument d2)
  {
    this.d2 = d2;
  }

  public RichDocument getD2()
  {
    return d2;
  }

  public void setPfl1(RichPanelFormLayout pfl1)
  {
    this.pfl1 = pfl1;
  }

  public RichPanelFormLayout getPfl1()
  {
    return pfl1;
  }

  public void setIt1(RichInputText it1)
  {
    this.it1 = it1;
  }

  public RichInputText getIt1()
  {
    return it1;
  }

  public void setOt1(RichOutputText ot1)
  {
    this.ot1 = ot1;
  }

  public RichOutputText getOt1()
  {
    return ot1;
  }

  public void setIt2(RichInputText it2)
  {
    this.it2 = it2;
  }

  public RichInputText getIt2()
  {
    return it2;
  }

  public void setPlam1(RichPanelLabelAndMessage plam1)
  {
    this.plam1 = plam1;
  }

  public RichPanelLabelAndMessage getPlam1()
  {
    return plam1;
  }

  public void setCb1(RichCommandButton cb1)
  {
    this.cb1 = cb1;
  }

  public RichCommandButton getCb1()
  {
    return cb1;
  }
}
