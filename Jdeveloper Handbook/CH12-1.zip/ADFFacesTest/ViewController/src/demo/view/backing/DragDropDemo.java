package demo.view.backing;

import oracle.adf.view.rich.component.rich.RichDocument;
import oracle.adf.view.rich.component.rich.RichForm;
import oracle.adf.view.rich.component.rich.input.RichInputText;
import oracle.adf.view.rich.component.rich.layout.RichPanelGroupLayout;
import oracle.adf.view.rich.component.rich.nav.RichCommandButton;
import oracle.adf.view.rich.component.rich.output.RichSeparator;
import oracle.adf.view.rich.component.rich.output.RichSpacer;

public class DragDropDemo
{
  private RichForm f2;
  private RichDocument d2;
  private RichInputText it1;
  private RichCommandButton cb1;
  private RichSeparator s1;
  private RichSpacer s2;
  private RichInputText it2;
  private RichPanelGroupLayout pgl1;

  public void setF2(RichForm f2)
  {
    this.f2 = f2;
  }

  public RichForm getF2()
  {
    return f2;
  }

  public void setD2(RichDocument d2)
  {
    this.d2 = d2;
  }

  public RichDocument getD2()
  {
    return d2;
  }

  public void setIt1(RichInputText it1)
  {
    this.it1 = it1;
  }

  public RichInputText getIt1()
  {
    return it1;
  }

  public void setCb1(RichCommandButton cb1)
  {
    this.cb1 = cb1;
  }

  public RichCommandButton getCb1()
  {
    return cb1;
  }

  public void setS1(RichSeparator s1)
  {
    this.s1 = s1;
  }

  public RichSeparator getS1()
  {
    return s1;
  }

  public void setS2(RichSpacer s2)
  {
    this.s2 = s2;
  }

  public RichSpacer getS2()
  {
    return s2;
  }

  public void setIt2(RichInputText it2)
  {
    this.it2 = it2;
  }

  public RichInputText getIt2()
  {
    return it2;
  }

  public void setPgl1(RichPanelGroupLayout pgl1)
  {
    this.pgl1 = pgl1;
  }

  public RichPanelGroupLayout getPgl1()
  {
    return pgl1;
  }


}
