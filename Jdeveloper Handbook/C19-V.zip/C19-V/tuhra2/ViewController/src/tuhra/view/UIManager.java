package tuhra.view;

import java.io.Serializable;

/**
04: * Class which manages persistent UI state
05: * for the application.
06: * Defined in the adfc-config.xml file as the
ch18.indd 662 9/15/09 10:13:35 AM
Oracle TIGHT / Oracle JDeveloper 11g Handbook: A Guide to Oracle Fusion Web Development / Mills, Koletzke & Roy-Faderman / 160238-0
Chapter 18: Sample Application: Search Page 663
07: * managed bean uiManager in session scope.
08: */
public class UIManager implements Serializable {
    //This list could grow as we add more Pages / Screens

    public enum Screen {
        EMPLOYEE_SEARCH,
        DEPARTMENT_TREE;
    }

    //Store the current screen state
    private Screen _searchScreenFocus = Screen.EMPLOYEE_SEARCH;

    /**
     * Set the searchScreenFocus flag from a text
     * version of the screen name
     * @param focus String matching the enumeration value
     */
    public void setSearchScreenFocus(String focus) {
        this._searchScreenFocus = Screen.valueOf(focus);
    }

    /**
     * Set the searchScreenFocus flag from the enum value
     * @param focus
     */
    public void setSearchScreenFocus(UIManager.Screen focus) {
        this._searchScreenFocus = focus;
    }

    /**
     * Return the searchScreenFocus as the enum constant
     * @return
     */
    public UIManager.Screen getSearchScreenFocus() {
        return _searchScreenFocus;
    }
}
