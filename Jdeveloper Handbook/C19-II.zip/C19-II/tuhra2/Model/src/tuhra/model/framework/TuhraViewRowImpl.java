package tuhra.model.framework;

import oracle.jbo.server.ViewRowImpl;

public class TuhraViewRowImpl extends ViewRowImpl {
}
